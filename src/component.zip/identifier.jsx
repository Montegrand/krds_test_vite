import React from "react";

function Identifier() {
  return (
    <>

<div className="krds-identifier">
<span className="logo">
<span className="sr-only">KRDS - Korea Design System</span>
</span>
<span className="ban-txt">이 누리집은 보건복지부 산하기관 누리집입니다.</span>
</div>

    </>
  );
}

export default Identifier;
