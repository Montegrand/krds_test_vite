import React from "react";

function Radio_size() {
  return (
    <>

<div className="krds-check-area">
<div className="krds-form-check medium">
<input id="rdo_2-2" name="rdo_2-1" type="radio"/>
<label htmlFor="rdo_2-2">사이즈 : medium</label>
</div>
<div className="krds-form-check large">
<input id="rdo_2-3" name="rdo_2-1" type="radio"/>
<label htmlFor="rdo_2-3">사이즈 : large</label>
</div>
</div>

    </>
  );
}

export default Radio_size;
