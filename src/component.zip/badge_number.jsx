import React from "react";

function Badge_number() {
  return (
    <>

<div className="krds-badge-wrap">
<span className="krds-badge bg-primary number">5</span>
<span className="krds-badge bg-primary number">999+</span>
</div>
<div className="krds-badge-wrap">
<span className="krds-badge bg-point number">5</span>
<span className="krds-badge bg-point number">999+</span>
</div>

    </>
  );
}

export default Badge_number;
