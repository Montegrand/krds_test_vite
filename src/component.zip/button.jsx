import React from "react";

function Button() {
  return (
    <>

<button className="krds-btn" type="button">버튼</button>

    </>
  );
}

export default Button;
