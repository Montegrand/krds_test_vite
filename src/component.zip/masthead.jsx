import React from "react";

function Masthead() {
  return (
    <>

<div id="krds-masthead">
<div className="toggle-wrap">
<div className="toggle-head">
<div className="inner">
<span className="nuri-txt">이 누리집은 대한민국 공식 전자정부 누리집입니다.</span>
</div>
</div>
</div>
</div>

    </>
  );
}

export default Masthead;
