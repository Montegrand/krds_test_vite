import React from "react";

function Button_hierarchy() {
  return (
    <>

<button className="krds-btn primary" type="button">버튼 : primary</button>
<button className="krds-btn secondary" type="button">버튼 : secondary</button>
<button className="krds-btn tertiary" type="button">버튼 : tertiary</button>

    </>
  );
}

export default Button_hierarchy;
