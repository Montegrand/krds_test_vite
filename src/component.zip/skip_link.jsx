import React from "react";

function Skip_link() {
  return (
    <>

<div id="krds-skip-link">
<a href="#breadcrumb">본문 바로가기</a>
</div>

    </>
  );
}

export default Skip_link;
