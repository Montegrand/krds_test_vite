import React from "react";

function Tag_link() {
  return (
    <>

<div className="krds-tag-wrap large">
<a className="krds-btn-tag link" href="#">
		태그
	</a>
<a className="krds-btn-tag link" href="#">
		태그
	</a>
<a className="krds-btn-tag link" href="#">
		태그
	</a>
</div>
<div className="krds-tag-wrap medium">
<a className="krds-btn-tag link" href="#">
		태그
	</a>
<a className="krds-btn-tag link" href="#">
		태그
	</a>
<a className="krds-btn-tag link" href="#">
		태그
	</a>
</div>
<div className="krds-tag-wrap small">
<a className="krds-btn-tag link" href="#">
		태그
	</a>
<a className="krds-btn-tag link" href="#">
		태그
	</a>
<a className="krds-btn-tag link" href="#">
		태그
	</a>
</div>

    </>
  );
}

export default Tag_link;
