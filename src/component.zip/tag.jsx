import React from "react";

function Tag() {
  return (
    <>

<div className="krds-tag-wrap large">
<span className="krds-btn-tag">
		태그
		<button className="btn-delete" type="button">
<span className="sr-only">삭제</span>
</button>
</span>
<span className="krds-btn-tag">
		태그
		<button className="btn-delete" type="button">
<span className="sr-only">삭제</span>
</button>
</span>
<span className="krds-btn-tag">
		태그
		<button className="btn-delete" type="button">
<span className="sr-only">삭제</span>
</button>
</span>
</div>
<div className="krds-tag-wrap medium">
<span className="krds-btn-tag">
		태그
		<button className="btn-delete" type="button">
<span className="sr-only">삭제</span>
</button>
</span>
<span className="krds-btn-tag">
		태그
		<button className="btn-delete" type="button">
<span className="sr-only">삭제</span>
</button>
</span>
<span className="krds-btn-tag">
		태그
		<button className="btn-delete" type="button">
<span className="sr-only">삭제</span>
</button>
</span>
</div>
<div className="krds-tag-wrap small">
<span className="krds-btn-tag">
		태그
		<button className="btn-delete" type="button">
<span className="sr-only">삭제</span>
</button>
</span>
<span className="krds-btn-tag">
		태그
		<button className="btn-delete" type="button">
<span className="sr-only">삭제</span>
</button>
</span>
<span className="krds-btn-tag">
		태그
		<button className="btn-delete" type="button">
<span className="sr-only">삭제</span>
</button>
</span>
</div>

    </>
  );
}

export default Tag;
